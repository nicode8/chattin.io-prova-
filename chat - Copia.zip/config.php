<?php

$DB_host= "db.fr-pari1.bengt.wasmernet.com";
$DB_name= "dbdili";
$DB_user= "a17adccc7a27800094e912c32dd5";
$DB_pass= "068fa17a-dccc-7bc4-8000-db55c4b98c8a";


?>